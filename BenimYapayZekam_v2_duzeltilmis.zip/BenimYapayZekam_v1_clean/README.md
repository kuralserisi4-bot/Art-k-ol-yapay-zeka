# Benim Yapay Zekam

Android project for building a debug APK with GitHub Actions.

The important project structure is:
- app/src/main/...
- app/build.gradle.kts
- settings.gradle.kts
- build.gradle.kts
- .github/workflows/build-apk.yml
